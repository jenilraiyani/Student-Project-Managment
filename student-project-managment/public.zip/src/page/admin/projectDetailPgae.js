import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ProjectDetails = () => {
  const navigate = useNavigate();

  // Mock Data directly reflecting the SPM_Project schema
  const [project] = useState({
    projectId: 1,
    projectTitle: 'E-Commerce Platform',
    description: 'Build a full-stack e-commerce web application with cart functionality, payment gateway integration, and a comprehensive admin dashboard for inventory management. The system must support role-based access and secure JWT authentication.',
    status: 'In Progress',
    startDate: '01 Sep 2024',
    endDate: '01 Mar 2025',
    assignedDate: '28 Aug 2024',
    faculty: { name: 'Dr. Nisha Kapoor', email: 'nisha.kapoor@spms.com', avatarColor: '#6B5CA5' },
    students: [
      { id: 's1', name: 'Priya Sharma', avatarColor: '#20C997' },
      { id: 's2', name: 'Rohan Mehta', avatarColor: '#3B82F6' }
    ],
    totalTasks: 15,
    completedTasks: 9,
    progressPercentage: 60.00
  });

  // Helper to get status badge classes
  const getStatusClass = (status) => {
    switch(status) {
      case 'Completed': return 'status-completed';
      case 'In Progress': return 'status-inprogress';
      case 'Not Started': return 'status-pending';
      default: return 'status-pending';
    }
  };

  return (
    <>
      {/* =========================================
          1. UI CODE
          ========================================= */}
      <div className="container-fluid p-0">
        
        {/* Page Header & Navigation */}
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
          <div>
            <h4 className="fw-bold mb-1 text-dark" style={{ letterSpacing: '-0.5px' }}>Project Details</h4>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb mb-0" style={{ fontSize: '0.85rem' }}>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Home</a></li>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Projects</a></li>
                <li className="breadcrumb-item active fw-semibold" aria-current="page">{project.projectTitle}</li>
              </ol>
            </nav>
          </div>
          
          {/* Top Actions */}
          <div className="d-flex gap-2">
            <button className="btn spms-btn-secondary d-flex align-items-center gap-2" onClick={() => navigate(-1)}>
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                <path fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
              </svg>
              Back
            </button>
            <button className="btn spms-btn-primary d-flex align-items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                <path fillRule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
              </svg>
              Edit Project
            </button>
          </div>
        </div>

        <div className="row g-4">
          
          {/* =========================================
              LEFT COLUMN: Overview & Timeline
              ========================================= */}
          <div className="col-12 col-xl-8">
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-body p-4 p-md-5">
                
                {/* Title & Status */}
                <div className="d-flex justify-content-between align-items-start mb-4 pb-3 border-bottom">
                  <div>
                    <span className="text-muted text-uppercase fw-bold" style={{ fontSize: '0.75rem', letterSpacing: '1px' }}>Project ID: PROJ-{project.projectId.toString().padStart(4, '0')}</span>
                    <h3 className="fw-bold text-dark mt-1 mb-0">{project.projectTitle}</h3>
                  </div>
                  <span className={`spms-detail-badge ${getStatusClass(project.status)}`}>
                    {project.status}
                  </span>
                </div>

                {/* Description */}
                <div className="mb-5">
                  <h6 className="fw-bold text-dark mb-3">Project Description</h6>
                  <p className="text-secondary lh-lg mb-0" style={{ fontSize: '0.95rem' }}>
                    {project.description}
                  </p>
                </div>

                {/* Timeline Grid */}
                <div className="bg-light rounded-4 p-4 mb-5 border" style={{ borderColor: '#F1F5F9' }}>
                  <h6 className="fw-bold text-dark mb-3">Project Timeline</h6>
                  <div className="row g-3">
                    <div className="col-sm-4">
                      <div className="d-flex align-items-center mb-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="#64748B" className="me-2" viewBox="0 0 16 16"><path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/></svg>
                        <span className="text-muted small fw-semibold text-uppercase">Start Date</span>
                      </div>
                      <div className="fw-bold text-dark">{project.startDate}</div>
                    </div>
                    <div className="col-sm-4 border-start border-sm-none pl-sm-3">
                      <div className="d-flex align-items-center mb-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="#64748B" className="me-2" viewBox="0 0 16 16"><path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/></svg>
                        <span className="text-muted small fw-semibold text-uppercase">End Date</span>
                      </div>
                      <div className="fw-bold text-dark">{project.endDate}</div>
                    </div>
                    <div className="col-sm-4 border-start border-sm-none pl-sm-3">
                      <div className="d-flex align-items-center mb-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="#6B5CA5" className="me-2" viewBox="0 0 16 16"><path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/><path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/></svg>
                        <span className="text-muted small fw-semibold text-uppercase">Assigned On</span>
                      </div>
                      <div className="fw-bold text-dark">{project.assignedDate}</div>
                    </div>
                  </div>
                </div>

                {/* Progress Bar Area */}
                <div>
                  <div className="d-flex justify-content-between align-items-end mb-2">
                    <h6 className="fw-bold text-dark mb-0">Overall Progress</h6>
                    <span className="fw-bold text-primary fs-5">{project.progressPercentage}%</span>
                  </div>
                  <div className="progress" style={{ height: '10px', borderRadius: '10px', backgroundColor: '#E2E8F0' }}>
                    <div 
                      className="progress-bar progress-bar-striped progress-bar-animated" 
                      role="progressbar" 
                      style={{ width: `${project.progressPercentage}%`, backgroundColor: '#6B5CA5' }} 
                      aria-valuenow={project.progressPercentage} 
                      aria-valuemin="0" 
                      aria-valuemax="100"
                    ></div>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* =========================================
              RIGHT COLUMN: Team & Statistics
              ========================================= */}
          <div className="col-12 col-xl-4">
            
            {/* Supervising Faculty Card */}
            <div className="card spms-premium-card border-0 mb-4">
              <div className="card-body p-4">
                <h6 className="fw-bold text-muted text-uppercase mb-4" style={{ fontSize: '0.75rem', letterSpacing: '1px' }}>Supervising Faculty</h6>
                <div className="d-flex align-items-center">
                  <div className="spms-detail-avatar me-3 shadow-sm" style={{ backgroundColor: project.faculty.avatarColor, width: '48px', height: '48px', fontSize: '1.2rem' }}>
                    {project.faculty.name.charAt(0)}
                  </div>
                  <div>
                    <h6 className="fw-bold text-dark mb-1">{project.faculty.name}</h6>
                    <p className="text-secondary small mb-0">{project.faculty.email}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Assigned Students Card */}
            <div className="card spms-premium-card border-0 mb-4">
              <div className="card-body p-4">
                <h6 className="fw-bold text-muted text-uppercase mb-4" style={{ fontSize: '0.75rem', letterSpacing: '1px' }}>Assigned Students</h6>
                <div className="d-flex flex-column gap-3">
                  {project.students.map((student) => (
                    <div key={student.id} className="d-flex align-items-center p-2 rounded-3" style={{ backgroundColor: '#F8FAFC' }}>
                      <div className="spms-detail-avatar me-3 shadow-sm" style={{ backgroundColor: student.avatarColor, width: '38px', height: '38px', fontSize: '1rem' }}>
                        {student.name.charAt(0)}
                      </div>
                      <span className="fw-semibold text-dark">{student.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Task Statistics Card */}
            <div className="card spms-premium-card border-0">
              <div className="card-body p-4">
                <h6 className="fw-bold text-muted text-uppercase mb-4" style={{ fontSize: '0.75rem', letterSpacing: '1px' }}>Task Summary</h6>
                
                <div className="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                  <span className="fw-semibold text-secondary">Total Tasks</span>
                  <span className="badge bg-light text-dark border px-3 py-2 fs-6">{project.totalTasks}</span>
                </div>
                
                <div className="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                  <span className="fw-semibold text-secondary">Completed</span>
                  <span className="badge bg-light text-success border border-success px-3 py-2 fs-6">{project.completedTasks}</span>
                </div>

                <div className="d-flex justify-content-between align-items-center">
                  <span className="fw-semibold text-secondary">Pending</span>
                  <span className="badge bg-light text-warning border border-warning px-3 py-2 fs-6">{project.totalTasks - project.completedTasks}</span>
                </div>
                
                <button className="btn btn-outline-primary w-100 mt-4 spms-btn-outline-primary">
                  View All Tasks
                </button>

              </div>
            </div>

          </div>

        </div>
      </div>

      {/* =========================================
          2. STYLE TAG
          ========================================= */}
      <style>
        {`
          /* Premium Card Styling */
          .spms-premium-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            border-top: 4px solid #6B5CA5 !important;
          }

          /* General Buttons */
          .spms-btn-primary {
            background-color: #6B5CA5;
            color: #FFFFFF;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            padding: 8px 18px;
          }
          .spms-btn-primary:hover {
            background-color: #55488c;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          .spms-btn-secondary {
            background-color: #64748B;
            color: #FFFFFF;
            font-weight: 600;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            padding: 8px 18px;
          }
          .spms-btn-secondary:hover {
            background-color: #475569;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.2);
          }

          .spms-btn-outline-primary {
            color: #6B5CA5;
            background-color: transparent;
            border: 1px solid rgba(107, 92, 165, 0.4);
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.2s;
          }
          .spms-btn-outline-primary:hover {
            background-color: #6B5CA5;
            color: #FFFFFF;
          }

          /* Status Badges */
          .spms-detail-badge {
            padding: 6px 16px;
            border-radius: 8px;
            font-size: 0.80rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: 1px solid transparent;
            display: inline-block;
          }
          .spms-detail-badge.status-completed { background-color: rgba(32, 201, 151, 0.1); color: #17a57a; border-color: rgba(32, 201, 151, 0.2); }
          .spms-detail-badge.status-inprogress { background-color: rgba(107, 92, 165, 0.1); color: #6B5CA5; border-color: rgba(107, 92, 165, 0.2); }
          .spms-detail-badge.status-pending { background-color: rgba(245, 158, 11, 0.1); color: #F59E0B; border-color: rgba(245, 158, 11, 0.2); }

          /* Avatars */
          .spms-detail-avatar {
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #FFFFFF;
            font-weight: bold;
          }
        `}
      </style>
    </>
  );
};

export default ProjectDetails;