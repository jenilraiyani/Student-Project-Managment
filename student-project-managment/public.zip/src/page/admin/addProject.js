import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddProject = () => {
  const navigate = useNavigate();
  
 
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState('In Progress');
  const [studentIds, setStudentIds] = useState([]); 
  const [facultyId, setFacultyId] = useState('');

 
  const availableStudents = [
    { id: 'stu_1', name: 'Priya Sharma' },
    { id: 'stu_2', name: 'Rohan Mehta' },
    { id: 'stu_3', name: 'Ananya Desai' },
    { id: 'stu_4', name: 'Karan Patel' },
    { id: 'stu_5', name: 'Aditi Verma' }
  ];

  
  const handleSave = (e) => {
    e.preventDefault();
    
    console.log("Saving Project:", { title, description, startDate, endDate, status, studentIds, facultyId });
    
    
    navigate(-1); 
  };

 
  const handleStudentToggle = (id) => {
    setStudentIds((prevSelected) => {
      if (prevSelected.includes(id)) {
        return prevSelected.filter((studentId) => studentId !== id); 
      } else {
        return [...prevSelected, id];
      }
    });
  };

  return (
    <>
    
      <div className="container-fluid p-0">
        
        
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h4 className="fw-bold mb-1 text-dark" style={{ letterSpacing: '-0.5px' }}>Add Project</h4>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb mb-0" style={{ fontSize: '0.85rem' }}>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Home</a></li>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Project Management</a></li>
                <li className="breadcrumb-item active fw-semibold" aria-current="page">Add</li>
              </ol>
            </nav>
          </div>
        </div>

        
        <div className="card spms-premium-card border-0">
          <div className="card-body p-4 p-md-5">
            
            <h6 className="fw-bold text-dark mb-4 pb-2 border-bottom">Project Details</h6>

            <form onSubmit={handleSave}>
              
              
              <div className="row mb-4 align-items-center">
                <label htmlFor="title" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Project Title
                </label>
                <div className="col-sm-9">
                  <input 
                    type="text" 
                    className="form-control spms-input shadow-none" 
                    id="title" 
                    placeholder="Enter project title" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
              </div>

             
              <div className="row mb-4">
                <label htmlFor="description" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Description
                </label>
                <div className="col-sm-9">
                  <textarea 
                    className="form-control spms-input shadow-none" 
                    id="description" 
                    rows="4" 
                    placeholder="Provide a brief description of the project objectives..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                  ></textarea>
                </div>
              </div>

              
              <div className="row mb-4 align-items-center">
                <label htmlFor="startDate" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Start Date
                </label>
                <div className="col-sm-4 mb-3 mb-sm-0">
                  <input 
                    type="date" 
                    className="form-control spms-input shadow-none" 
                    id="startDate" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    required
                  />
                </div>
                
                <label htmlFor="endDate" className="col-sm-1 col-form-label fw-semibold text-secondary text-sm-end px-0">
                  End Date
                </label>
                <div className="col-sm-4">
                  <input 
                    type="date" 
                    className="form-control spms-input shadow-none" 
                    id="endDate" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    required
                  />
                </div>
              </div>

              
              <div className="row mb-4 align-items-center">
                <label htmlFor="status" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Status
                </label>
                <div className="col-sm-4 mb-3 mb-sm-0">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                  >
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
                
                <label htmlFor="facultyId" className="col-sm-1 col-form-label fw-semibold text-secondary text-sm-end px-0">
                  Faculty
                </label>
                <div className="col-sm-4">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="facultyId"
                    value={facultyId}
                    onChange={(e) => setFacultyId(e.target.value)}
                    required
                  >
                    <option value="" disabled>-- Select --</option>
                    <option value="fac_1">Dr. Nisha Kapoor</option>
                    <option value="fac_2">Vikram Singh</option>
                  </select>
                </div>
              </div>

             
              <div className="row mb-5">
                <label className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Assign Students
                </label>
                <div className="col-sm-9">
                 
                  <div className="form-control spms-input shadow-none h-auto p-3" style={{ minHeight: '100px' }}>
                    <div className="d-flex flex-wrap gap-2">
                      {availableStudents.map((student) => {
                        const isSelected = studentIds.includes(student.id);
                        return (
                          <div 
                            key={student.id}
                            className={`student-select-card shadow-sm ${isSelected ? 'selected' : ''}`}
                            onClick={() => handleStudentToggle(student.id)}
                          >
                            {student.name}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

             
              <div className="row">
                <div className="col-sm-3"></div>
                <div className="col-sm-9 d-flex gap-2">
                  <button type="submit" className="btn spms-btn-primary d-flex align-items-center gap-2 shadow-sm">
                    
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                    </svg>
                    Save Project
                  </button>
                  
                  <button 
                    type="button" 
                    className="btn spms-btn-secondary d-flex align-items-center gap-2 shadow-sm"
                    onClick={() => navigate(-1)}
                  >
                   
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                      <path fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                    </svg>
                    Back
                  </button>
                </div>
              </div>

            </form>

          </div>
        </div>
      </div>

    
      <style>
        {`
          /* Premium Card Styling */
          .spms-premium-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            border-top: 4px solid #6B5CA5 !important; /* Purple Accent from theme */
          }

          /* Input Fields */
          .spms-input {
            border-radius: 8px;
            border: 1px solid #E2E8F0;
            background-color: #F8FAFC;
            font-size: 0.95rem;
            padding: 10px 15px;
            color: #1E293B;
            transition: all 0.2s;
          }

          .spms-input::placeholder {
            color: #94A3B8;
            font-size: 0.9rem;
          }

          .spms-input:focus {
            background-color: #FFFFFF;
            border-color: #6B5CA5;
            box-shadow: 0 0 0 3px rgba(107, 92, 165, 0.1) !important;
          }

          /* Modern Student Select Cards */
          .student-select-card {
            padding: 8px 16px;
            border-radius: 20px; /* Pill shape looks modern */
            border: 1px solid #E2E8F0;
            background-color: #FFFFFF;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            color: #475569;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            user-select: none;
          }

          .student-select-card:hover {
            border-color: #CBD5E1;
            background-color: #F8FAFC;
            transform: translateY(-1px);
          }

          .student-select-card.selected {
            background-color: rgba(107, 92, 165, 0.1); /* Theme Purple tint */
            border-color: #6B5CA5;
            color: #6B5CA5;
            font-weight: 600;
          }

          /* Primary Save Button */
          .spms-btn-primary {
            background-color: #6B5CA5; /* Purple Accent */
            color: #FFFFFF;
            font-weight: 600;
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
          }

          .spms-btn-primary:hover {
            background-color: #55488c;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          /* Secondary Back Button */
          .spms-btn-secondary {
            background-color: #64748B; /* Slate Gray */
            color: #FFFFFF;
            font-weight: 600;
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
          }

          .spms-btn-secondary:hover {
            background-color: #475569;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.2);
          }

          /* Label Styling */
          .col-form-label {
            font-size: 0.95rem;
          }
        `}
      </style>
    </>
  );
};

export default AddProject;