import React from 'react';

const Dashboard = () => {
  // Static Mock Data based on the SPMS schema concepts
  const kpiData = [
    { id: 1, title: 'Total Students', count: '1,245', iconColor: '#3B82F6', bgColor: 'rgba(59, 130, 246, 0.1)', 
      svg: <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/> 
    },
    { id: 2, title: 'Total Faculty', count: '84', iconColor: '#6B5CA5', bgColor: 'rgba(107, 92, 165, 0.1)', 
      svg: <path fillRule="evenodd" d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm7 1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5z"/> 
    },
    { id: 3, title: 'Active Projects', count: '312', iconColor: '#F59E0B', bgColor: 'rgba(245, 158, 11, 0.1)', 
      svg: <path fillRule="evenodd" d="M8 0a.5.5 0 0 1 .5.5v2h3a2 2 0 0 1 2 2v2h1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-1v5a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V9H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 6h1V4.5a2 2 0 0 1 2-2h3v-2A.5.5 0 0 1 8 0zM2 4.5V6h12V4.5a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1zM13 7H3v7a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V7z"/> 
    },
    { id: 4, title: 'Completed Projects', count: '890', iconColor: '#20C997', bgColor: 'rgba(32, 201, 151, 0.1)', 
      svg: <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/> 
    }
  ];

  const recentProjects = [
    { id: 1, title: 'AI Chatbot Integration', student: 'Priya Sharma', status: 'In Progress', date: '15 Aug 2026', badgeClass: 'badge-inprogress' },
    { id: 2, title: 'E-commerce React App', student: 'Rohan Mehta', status: 'Pending', date: '30 Nov 2026', badgeClass: 'badge-pending' },
    { id: 3, title: 'Hospital Management API', student: 'Ananya Desai', status: 'Completed', date: '10 Jul 2026', badgeClass: 'badge-completed' },
    { id: 4, title: 'Blockchain Voting System', student: 'Karan Patel', status: 'In Progress', date: '25 Sep 2026', badgeClass: 'badge-inprogress' }
  ];

  const upcomingDeadlines = [
    { id: 1, title: 'Library Management DB', days: '2 Days Left', date: '06 Jul 2026', color: '#dc3545' },
    { id: 2, title: 'IoT Weather Station', days: '5 Days Left', date: '09 Jul 2026', color: '#F59E0B' },
    { id: 3, title: 'React Native Social App', days: '1 Week Left', date: '11 Jul 2026', color: '#6B5CA5' }
  ];

  // Updated: Recent Tasks Data instead of Recent Activity
  const recentTasks = [
    { id: 1, title: 'Design Database Schema', project: 'E-commerce React App', assignedTo: 'Rohan Mehta', priority: 'High', status: 'In Progress' },
    { id: 2, title: 'Implement JWT Authentication', project: 'Hospital Management API', assignedTo: 'Ananya Desai', priority: 'High', status: 'Pending' },
    { id: 3, title: 'Create UI Wireframes', project: 'AI Chatbot Integration', assignedTo: 'Priya Sharma', priority: 'Medium', status: 'Completed' },
    { id: 4, title: 'Setup CI/CD Pipeline', project: 'Blockchain Voting System', assignedTo: 'Karan Patel', priority: 'Low', status: 'Pending' }
  ];

  return (
    <>
      {/* =========================================
          1. UI CODE
          ========================================= */}
      <div className="container-fluid p-0">
        
        {/* Page Header (Animated) */}
        <div className="d-flex justify-content-between align-items-center mb-4 spms-animate-up" style={{ animationDelay: '0.1s' }}>
          <div>
            <h4 className="fw-bold mb-1 text-dark" style={{ letterSpacing: '-0.5px' }}>Dashboard Overview</h4>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb mb-0" style={{ fontSize: '0.85rem' }}>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Home</a></li>
                <li className="breadcrumb-item active fw-semibold" aria-current="page">Dashboard</li>
              </ol>
            </nav>
          </div>
          <div>
            <button className="btn spms-btn-primary shadow-sm d-flex align-items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
              </svg>
              Generate Report
            </button>
          </div>
        </div>

        {/* Row 1: KPI Metric Cards (Animated) */}
        <div className="row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4 mb-4">
          {kpiData.map((kpi, index) => (
            <div className="col spms-animate-up" style={{ animationDelay: `${0.2 + (index * 0.1)}s` }} key={kpi.id}>
              <div className="card spms-kpi-card h-100 border-0 shadow-sm">
                <div className="card-body d-flex align-items-center p-4">
                  <div className="kpi-icon-box me-3" style={{ backgroundColor: kpi.bgColor, color: kpi.iconColor }}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                      {kpi.svg}
                    </svg>
                  </div>
                  <div>
                    <h6 className="text-muted fw-semibold mb-1 text-uppercase" style={{ fontSize: '0.75rem', letterSpacing: '0.5px' }}>
                      {kpi.title}
                    </h6>
                    <h3 className="fw-bold mb-0 text-dark">{kpi.count}</h3>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Row 2: Charts and Tables (Animated) */}
        <div className="row g-4 mb-4">
          
          {/* Recent Projects Table */}
          <div className="col-12 col-xl-8 spms-animate-up" style={{ animationDelay: '0.6s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-0 px-4 d-flex justify-content-between align-items-center">
                <h6 className="fw-bold text-dark mb-0">Recent Projects Assigned</h6>
                <a href="#" className="text-decoration-none text-primary fw-semibold" style={{ fontSize: '0.85rem' }}>View All</a>
              </div>
              <div className="card-body p-4 pt-3">
                <div className="table-responsive">
                  <table className="table table-hover align-middle spms-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '40%' }}>Project Name</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '25%' }}>Student</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '20%' }}>Status</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3 text-end" style={{ width: '15%' }}>End Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentProjects.map((project) => (
                        <tr key={project.id}>
                          <td>
                            <span className="fw-semibold text-dark">{project.title}</span>
                          </td>
                          <td className="text-secondary fw-medium">
                            <div className="d-flex align-items-center">
                              <div className="avatar-circle me-2 bg-light text-primary fw-bold" style={{ width: '24px', height: '24px', fontSize: '0.7rem' }}>
                                {project.student.charAt(0)}
                              </div>
                              <span style={{ fontSize: '0.9rem' }}>{project.student}</span>
                            </div>
                          </td>
                          <td>
                            <span className={`spms-badge ${project.badgeClass}`}>
                              {project.status}
                            </span>
                          </td>
                          <td className="text-secondary text-end small fw-medium">{project.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Project Status Overview */}
          <div className="col-12 col-xl-4 spms-animate-up" style={{ animationDelay: '0.7s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-0 px-4">
                <h6 className="fw-bold text-dark mb-0">Project Status Overview</h6>
              </div>
              <div className="card-body p-4 d-flex flex-column justify-content-center">
                
                {/* Status: Completed */}
                <div className="mb-4">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>Completed</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>65%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '65%', backgroundColor: '#20C997' }} aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

                {/* Status: In Progress */}
                <div className="mb-4">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>In Progress</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>25%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '25%', backgroundColor: '#6B5CA5' }} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

                {/* Status: Pending */}
                <div className="mb-2">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>Pending Approval</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>10%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '10%', backgroundColor: '#F59E0B' }} aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>

        {/* Row 3: New Additions (Upcoming Deadlines & Recent Tasks) - Animated */}
        <div className="row g-4">
          
          {/* Upcoming Deadlines */}
          <div className="col-12 col-xl-6 spms-animate-up" style={{ animationDelay: '0.8s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
                <h6 className="fw-bold text-dark mb-0">Upcoming Deadlines</h6>
              </div>
              <div className="card-body p-4 pt-1">
                <ul className="list-group list-group-flush">
                  {upcomingDeadlines.map((item) => (
                    <li key={item.id} className="list-group-item px-0 py-3 border-bottom d-flex justify-content-between align-items-center" style={{ borderColor: '#F1F5F9' }}>
                      <div className="d-flex align-items-center">
                        <div className="me-3" style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: item.color }}></div>
                        <div>
                          <h6 className="mb-1 fw-bold text-dark" style={{ fontSize: '0.9rem' }}>{item.title}</h6>
                          <span className="text-secondary small">{item.date}</span>
                        </div>
                      </div>
                      <span className="badge rounded-pill fw-semibold px-3 py-2" style={{ backgroundColor: `${item.color}15`, color: item.color, fontSize: '0.75rem' }}>
                        {item.days}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Recent Tasks - Replacing Recent Activity */}
          <div className="col-12 col-xl-6 spms-animate-up" style={{ animationDelay: '0.9s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
                <h6 className="fw-bold text-dark mb-0">Recent Tasks Assigned</h6>
                <a href="#" className="text-decoration-none text-primary fw-semibold" style={{ fontSize: '0.85rem' }}>View All</a>
              </div>
              <div className="card-body p-4 pt-2">
                <div className="table-responsive">
                  <table className="table table-hover align-middle spms-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '30%' }}>Task</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '25%' }}>Project</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '20%' }}>Assigned To</th>
                       
                      </tr>
                    </thead>
                    <tbody>
                      {recentTasks.map((task) => (
                        <tr key={task.id}>
                          <td>
                            <span className="fw-semibold text-dark" style={{ fontSize: '0.85rem' }}>{task.title}</span>
                          </td>
                          <td className="text-secondary" style={{ fontSize: '0.8rem' }}>{task.project}</td>
                          <td>
                            <div className="d-flex align-items-center">
                              <div className="avatar-circle me-2 bg-light text-primary fw-bold" style={{ width: '24px', height: '24px', fontSize: '0.7rem' }}>
                                {task.assignedTo.charAt(0)}
                              </div>
                              <span style={{ fontSize: '0.8rem' }}>{task.assignedTo}</span>
                            </div>
                          </td>
                         
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* =========================================
          2. STYLE TAG (Placed after UI code)
          ========================================= */}
      <style>
        {`
          /* Professional Keyframe Animations */
          @keyframes fadeInUp {
            0% {
              opacity: 0;
              transform: translateY(30px);
            }
            100% {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .spms-animate-up {
            opacity: 0; /* Elements start hidden */
            animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          }

          /* Premium Card Styling */
          .spms-premium-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            border-top: 4px solid #6B5CA5 !important; /* Purple Accent */
          }

          /* KPI Card Styling */
          .spms-kpi-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
          }
          
          .spms-kpi-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08) !important;
          }

          .kpi-icon-box {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
          }

          /* Primary Button */
          .spms-btn-primary {
            background-color: #6B5CA5; /* Purple Accent */
            color: #FFFFFF;
            font-weight: 600;
            padding: 8px 18px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
          }

          .spms-btn-primary:hover {
            background-color: #55488c;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          /* Table Styling */
          .spms-table th {
            font-size: 0.70rem;
            letter-spacing: 0.8px;
            border-bottom: 2px solid #F1F5F9;
            color: #64748B !important;
          }

          .spms-table td {
            font-size: 0.95rem;
            padding: 12px 10px;
            border-bottom: 1px solid #F1F5F9;
            vertical-align: middle;
          }
          
          .spms-table tbody tr:last-child td {
            border-bottom: none;
          }

          /* Professional Status Badges */
          .spms-badge {
            padding: 5px 10px;
            border-radius: 6px;
            font-size: 0.70rem;
            font-weight: 700;
            display: inline-block;
            letter-spacing: 0.3px;
            text-transform: uppercase;
          }

          .badge-completed {
            background-color: rgba(32, 201, 151, 0.1);
            color: #17a57a;
            border: 1px solid rgba(32, 201, 151, 0.2);
          }

          .badge-inprogress {
            background-color: rgba(107, 92, 165, 0.1);
            color: #6B5CA5;
            border: 1px solid rgba(107, 92, 165, 0.2);
          }

          .badge-pending {
            background-color: rgba(245, 158, 11, 0.1);
            color: #D97706;
            border: 1px solid rgba(245, 158, 11, 0.2);
          }

          /* Avatar Circle */
          .avatar-circle {
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(107, 92, 165, 0.2);
          }
        `}
      </style>
    </>
  );
};

export default Dashboard;