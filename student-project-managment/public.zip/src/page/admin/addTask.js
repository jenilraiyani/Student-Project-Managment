import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddTask = () => {
  const navigate = useNavigate();
  

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [status, setStatus] = useState('Pending');
  const [assignType, setAssignType] = useState('Student');
  const [assignedTo, setAssignedTo] = useState('');

  
  const handleSave = (e) => {
    e.preventDefault();
 
    console.log("Saving Task:", { title, description, projectId, dueDate, priority, status, assignType, assignedTo });
    
   
    navigate(-1); 
  };

  return (
    <>
      
      <div className="container-fluid p-0">
        
        
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h4 className="fw-bold mb-1 text-dark" style={{ letterSpacing: '-0.5px' }}>Add Task</h4>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb mb-0" style={{ fontSize: '0.85rem' }}>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Home</a></li>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Project Management</a></li>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Tasks</a></li>
                <li className="breadcrumb-item active fw-semibold" aria-current="page">Add</li>
              </ol>
            </nav>
          </div>
        </div>

        
        <div className="card spms-premium-card border-0">
          <div className="card-body p-4 p-md-5">
            
            <h6 className="fw-bold text-dark mb-4 pb-2 border-bottom">Task Details</h6>

            <form onSubmit={handleSave}>
              
              
              <div className="row mb-4 align-items-center">
                <label htmlFor="title" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Task Title
                </label>
                <div className="col-sm-9">
                  <input 
                    type="text" 
                    className="form-control spms-input shadow-none" 
                    id="title" 
                    placeholder="Enter task title" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
              </div>

              
              <div className="row mb-4">
                <label htmlFor="description" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Description
                </label>
                <div className="col-sm-9">
                  <textarea 
                    className="form-control spms-input shadow-none" 
                    id="description" 
                    rows="3" 
                    placeholder="Provide detailed instructions for this task..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  ></textarea>
                </div>
              </div>

              
              <div className="row mb-4 align-items-center">
                <label htmlFor="projectId" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Related Project
                </label>
                <div className="col-sm-9">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="projectId"
                    value={projectId}
                    onChange={(e) => setProjectId(e.target.value)}
                    required
                  >
                    <option value="" disabled>-- Select a Project --</option>
                    <option value="proj_1">University Website Redesign</option>
                    <option value="proj_2">Student Portal Migration</option>
                    <option value="proj_3">Mobile App Development</option>
                  </select>
                </div>
              </div>

              
              <div className="row mb-4 align-items-center">
                <label htmlFor="dueDate" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Due Date
                </label>
                <div className="col-sm-9">
                  <input 
                    type="date" 
                    className="form-control spms-input shadow-none w-50" 
                    id="dueDate" 
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    required
                  />
                </div>
              </div>

              
              <div className="row mb-4 align-items-center">
                <label htmlFor="priority" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Priority
                </label>
                <div className="col-sm-4 mb-3 mb-sm-0">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="priority"
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
                
                <label htmlFor="status" className="col-sm-1 col-form-label fw-semibold text-secondary text-sm-end px-0">
                  Status
                </label>
                <div className="col-sm-4">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                  >
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              
              <div className="row mb-5 align-items-center">
                <label htmlFor="assignType" className="col-sm-3 col-form-label fw-semibold text-secondary">
                  Assign Type
                </label>
                <div className="col-sm-4 mb-3 mb-sm-0">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="assignType"
                    value={assignType}
                    onChange={(e) => {
                      setAssignType(e.target.value);
                      setAssignedTo(''); 
                    }}
                  >
                    <option value="Student">Student</option>
                    <option value="Faculty">Faculty</option>
                  </select>
                </div>
                
                <label htmlFor="assignedTo" className="col-sm-1 col-form-label fw-semibold text-secondary text-sm-end px-0">
                  Assign To
                </label>
                <div className="col-sm-4">
                  <select 
                    className="form-select spms-input shadow-none" 
                    id="assignedTo"
                    value={assignedTo}
                    onChange={(e) => setAssignedTo(e.target.value)}
                    required
                  >
                    <option value="" disabled>-- Select Assign To --</option>
                    {assignType === 'Student' ? (
                      <>
                        <option value="stu_1">Priya Sharma</option>
                        <option value="stu_2">Rohan Mehta</option>
                        <option value="stu_3">Ananya Desai</option>
                      </>
                    ) : (
                      <>
                        <option value="fac_1">Dr. Nisha Kapoor</option>
                        <option value="fac_2">Vikram Singh</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div className="row">
                <div className="col-sm-3"></div>
                <div className="col-sm-9 d-flex gap-2">
                  <button type="submit" className="btn spms-btn-primary d-flex align-items-center gap-2 shadow-sm">
                    
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                    </svg>
                    Save Task
                  </button>
                  
                  <button 
                    type="button" 
                    className="btn spms-btn-secondary d-flex align-items-center gap-2 shadow-sm"
                    onClick={() => navigate(-1)}
                  >
                    
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                      <path fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                    </svg>
                    Back
                  </button>
                </div>
              </div>

            </form>

          </div>
        </div>
      </div>

     
      <style>
        {`
          /* Premium Card Styling */
          .spms-premium-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            border-top: 4px solid #6B5CA5 !important; /* Purple Accent from theme */
          }

          /* Input Fields */
          .spms-input {
            border-radius: 8px;
            border: 1px solid #E2E8F0;
            background-color: #F8FAFC;
            font-size: 0.95rem;
            padding: 10px 15px;
            color: #1E293B;
            transition: all 0.2s;
          }

          .spms-input::placeholder {
            color: #94A3B8;
            font-size: 0.9rem;
          }

          .spms-input:focus {
            background-color: #FFFFFF;
            border-color: #6B5CA5;
            box-shadow: 0 0 0 3px rgba(107, 92, 165, 0.1) !important;
          }

          /* Primary Save Button */
          .spms-btn-primary {
            background-color: #6B5CA5; /* Purple Accent */
            color: #FFFFFF;
            font-weight: 600;
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
          }

          .spms-btn-primary:hover {
            background-color: #55488c;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          /* Secondary Back Button */
          .spms-btn-secondary {
            background-color: #64748B; /* Slate Gray */
            color: #FFFFFF;
            font-weight: 600;
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
          }

          .spms-btn-secondary:hover {
            background-color: #475569;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.2);
          }

          /* Label Styling */
          .col-form-label {
            font-size: 0.95rem;
          }
        `}
      </style>
    </>
  );
};

export default AddTask;