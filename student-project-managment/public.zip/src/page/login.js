import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  
  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Form submission handler
  const handleLogin = (e) => {
    e.preventDefault();
    // API call for authentication will go here
    console.log("Logging in with:", { email, password });
    
    // Simulate successful login and navigate to dashboard
    navigate('/'); 
  };

  return (
    <>
      {/* =========================================
          1. UI CODE
          ========================================= */}
      <div className="login-wrapper d-flex align-items-center justify-content-center position-relative overflow-hidden">
        
        {/* Decorative Background Elements */}
        <div className="bg-shape shape-1"></div>
        <div className="bg-shape shape-2"></div>

        <div className="container position-relative" style={{ zIndex: 10 }}>
          <div className="row justify-content-center">
            <div className="col-12 col-sm-10 col-md-8 col-lg-5 col-xl-4">
              
              {/* Premium Animated Login Card */}
              <div className="card spms-login-card border-0 p-4 p-sm-5 spms-animate-fade-in">
                
                {/* Brand / Logo Area */}
                <div className="text-center mb-4 pb-3">
                  <div className="brand-icon mx-auto mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M14 4.577v6.846L8 15l-6-3.577V4.577L8 1l6 3.577zM8.5.134a1 1 0 0 0-1 0l-6 3.577a1 1 0 0 0-.5.866v6.846a1 1 0 0 0 .5.866l6 3.577a1 1 0 0 0 1 0l6-3.577a1 1 0 0 0 .5-.866V4.577a1 1 0 0 0-.5-.866L8.5.134z"/>
                      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                    </svg>
                  </div>
                  <h4 className="fw-bolder text-dark mb-1" style={{ letterSpacing: '-0.5px' }}>Welcome Back</h4>
                  <p className="text-muted small fw-medium">Sign in to your SPMS account</p>
                </div>

                <form onSubmit={handleLogin}>
                  
                  {/* Email Field with Icon */}
                  <div className="mb-4">
                    <label htmlFor="email" className="form-label fw-bold text-secondary small mb-2" style={{ letterSpacing: '0.3px' }}>
                      Email Address
                    </label>
                    <div className="position-relative">
                      <div className="position-absolute top-50 start-0 translate-middle-y ms-3 text-muted">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                          <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
                        </svg>
                      </div>
                      <input 
                        type="email" 
                        className="form-control spms-input shadow-none py-2 ps-5" 
                        id="email" 
                        placeholder="name@example.com" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Password Field with Icon */}
                  <div className="mb-4">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <label htmlFor="password" className="form-label fw-bold text-secondary small mb-0" style={{ letterSpacing: '0.3px' }}>
                        Password
                      </label>
                      <a href="#" className="text-decoration-none text-primary small fw-bold">
                        Forgot Password?
                      </a>
                    </div>
                    <div className="position-relative">
                      <div className="position-absolute top-50 start-0 translate-middle-y ms-3 text-muted">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                          <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                        </svg>
                      </div>
                      <input 
                        type="password" 
                        className="form-control spms-input shadow-none py-2 ps-5" 
                        id="password" 
                        placeholder="Enter your password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <button type="submit" className="btn spms-btn-login w-100 py-2 d-flex justify-content-center align-items-center gap-2 mt-4">
                    Sign In
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style={{ transition: 'transform 0.3s ease' }} className="btn-icon">
                      <path fillRule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"/>
                    </svg>
                  </button>

                </form>

              </div>

              {/* Footer Text */}
              <div className="text-center mt-4 spms-animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <p className="text-secondary small fw-medium">
                  Student Project Management System © 2026
                </p>
              </div>

            </div>
          </div>
        </div>

      </div>

      {/* =========================================
          2. STYLE TAG (Placed after UI code)
          ========================================= */}
      <style>
        {`
          /* Full Screen Wrapper with Modern Background */
          .login-wrapper {
            min-height: 100vh;
            background-color: #F1F5F9; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          }

          /* Soft glowing decorative shapes in background */
          .bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            z-index: 1;
            opacity: 0.6;
          }

          .shape-1 {
            width: 400px;
            height: 400px;
            background-color: rgba(107, 92, 165, 0.15); /* Purple glow */
            top: -100px;
            right: -100px;
          }

          .shape-2 {
            width: 300px;
            height: 300px;
            background-color: rgba(59, 130, 246, 0.1); /* Blue glow */
            bottom: -50px;
            left: -100px;
          }

          /* Entrance Animation */
          @keyframes slideUpFade {
            0% {
              opacity: 0;
              transform: translateY(20px);
            }
            100% {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .spms-animate-fade-in {
            animation: slideUpFade 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            opacity: 0; /* Starts hidden */
          }

          /* Ultra-Premium Card Styling */
          .spms-login-card {
            border-radius: 20px;
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.04), 0 1px 3px rgba(0,0,0,0.02);
            border: 1px solid rgba(255,255,255,0.4) !important;
            border-top: 5px solid #6B5CA5 !important;
          }

          /* Glowing Brand Icon */
          .brand-icon {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(107, 92, 165, 0.1) 0%, rgba(107, 92, 165, 0.2) 100%);
            color: #6B5CA5;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: inset 0 0 0 1px rgba(107, 92, 165, 0.1);
          }

          /* Input Fields */
          .spms-input {
            border-radius: 10px;
            border: 1px solid #E2E8F0;
            background-color: #F8FAFC;
            font-size: 0.95rem;
            color: #1E293B;
            transition: all 0.2s;
          }

          .spms-input::placeholder {
            color: #94A3B8;
            font-size: 0.9rem;
          }

          .spms-input:focus {
            background-color: #FFFFFF;
            border-color: #6B5CA5;
            box-shadow: 0 0 0 4px rgba(107, 92, 165, 0.1) !important;
          }
          
          /* Icon inside input */
          .position-relative .text-muted {
            transition: color 0.2s ease;
          }
          
          .position-relative:focus-within .text-muted {
            color: #6B5CA5 !important;
          }

          /* Text Links */
          .text-primary {
            color: #6B5CA5 !important;
            transition: all 0.2s ease;
          }

          .text-primary:hover {
            color: #55488c !important;
            text-decoration: underline !important;
          }

          /* Gradient Primary Button */
          .spms-btn-login {
            background: linear-gradient(135deg, #6B5CA5 0%, #55488c 100%);
            color: #FFFFFF;
            font-weight: 600;
            border-radius: 10px;
            border: none;
            transition: all 0.3s ease;
            font-size: 1rem;
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          .spms-btn-login:hover {
            background: linear-gradient(135deg, #7b6ab5 0%, #453775 100%);
            color: #FFFFFF;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(107, 92, 165, 0.3);
          }
          
          .spms-btn-login:hover .btn-icon {
            transform: translateX(4px);
          }
        `}
      </style>
    </>
  );
};

export default Login;