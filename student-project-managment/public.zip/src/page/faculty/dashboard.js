import React from 'react';

const FacultyDashboard = () => {
  // Mock Data tailored specifically for the Faculty Role
  const kpiData = [
    { id: 1, title: 'My Active Projects', count: '4', subtitle: 'currently supervising', iconColor: '#3B82F6', bgColor: 'rgba(59, 130, 246, 0.1)', 
      svg: <path fillRule="evenodd" d="M8 0a.5.5 0 0 1 .5.5v2h3a2 2 0 0 1 2 2v2h1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-1v5a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V9H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 6h1V4.5a2 2 0 0 1 2-2h3v-2A.5.5 0 0 1 8 0zM2 4.5V6h12V4.5a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1zM13 7H3v7a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V7z"/> 
    },
    { id: 2, title: 'My Students', count: '12', subtitle: 'assigned to my projects', iconColor: '#20C997', bgColor: 'rgba(32, 201, 151, 0.1)', 
      svg: <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/> 
    },
    { id: 3, title: 'Pending Evaluations', count: '5', subtitle: 'tasks to be graded', iconColor: '#F59E0B', bgColor: 'rgba(245, 158, 11, 0.1)', 
      svg: <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/> 
    },
    { id: 4, title: 'Avg. Project Progress', count: '68%', subtitle: 'overall completion rate', iconColor: '#6B5CA5', bgColor: 'rgba(107, 92, 165, 0.1)', 
      svg: <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/> 
    }
  ];

  const myProjects = [
    { id: 1, title: 'E-commerce Platform', students: 'Priya S., Rohan M.', progress: 75, date: '01 Mar 2025' },
    { id: 2, title: 'Mobile App Development', students: 'Aditi V.', progress: 40, date: '30 Jun 2025' },
    { id: 3, title: 'University Website Redesign', students: 'Karan P., Ananya D.', progress: 90, date: '15 Dec 2024' }
  ];

  const tasksToEvaluate = [
    { id: 1, title: 'Write SRS Document', project: 'Mobile App', student: 'Aditi Verma', submittedDate: '10 Sep 2024' },
    { id: 2, title: 'Implement Payment Gateway', project: 'E-commerce', student: 'Rohan Mehta', submittedDate: '11 Sep 2024' },
    { id: 3, title: 'Design Database Schema', project: 'University Web', student: 'Karan Patel', submittedDate: '12 Sep 2024' }
  ];

  // Helper for Progress Bar colors
  const getProgressColor = (progress) => {
    if (progress >= 80) return '#20C997'; // Green
    if (progress >= 50) return '#6B5CA5'; // Purple
    return '#F59E0B'; // Orange
  };

  return (
    <>
      {/* =========================================
          1. UI CODE
          ========================================= */}
      <div className="container-fluid p-0">
        
        {/* Page Header (Animated) */}
        <div className="d-flex justify-content-between align-items-center mb-4 spms-animate-up" style={{ animationDelay: '0.1s' }}>
          <div>
            <h4 className="fw-bold mb-1 text-dark" style={{ letterSpacing: '-0.5px' }}>Faculty Dashboard</h4>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb mb-0" style={{ fontSize: '0.85rem' }}>
                <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-muted">Home</a></li>
                <li className="breadcrumb-item active fw-semibold" aria-current="page">Dashboard</li>
              </ol>
            </nav>
          </div>
          <div className="d-flex gap-2">
            <button className="btn btn-outline-primary spms-btn-outline d-flex align-items-center gap-2 shadow-sm bg-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                <path fillRule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
              </svg>
              Assign New Task
            </button>
            <button className="btn spms-btn-primary shadow-sm d-flex align-items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
              </svg>
              My Reports
            </button>
          </div>
        </div>

        {/* Row 1: KPI Metric Cards (Animated) */}
        <div className="row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4 mb-4">
          {kpiData.map((kpi, index) => (
            <div className="col spms-animate-up" style={{ animationDelay: `${0.2 + (index * 0.1)}s` }} key={kpi.id}>
              <div className="card spms-kpi-card h-100 border-0 shadow-sm">
                <div className="card-body p-4">
                  <div className="d-flex align-items-center mb-3">
                    <div className="kpi-icon-box me-3" style={{ backgroundColor: kpi.bgColor, color: kpi.iconColor }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
                        {kpi.svg}
                      </svg>
                    </div>
                    <h6 className="text-muted fw-semibold mb-0" style={{ fontSize: '0.85rem' }}>{kpi.title}</h6>
                  </div>
                  <div>
                    <h3 className="fw-bold mb-0 text-dark d-inline-block me-2">{kpi.count}</h3>
                    <span className="text-secondary small fw-medium">{kpi.subtitle}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Row 2: Projects Overview & Task Status */}
        <div className="row g-4 mb-4">
          
          {/* Supervised Projects Table */}
          <div className="col-12 col-xl-8 spms-animate-up" style={{ animationDelay: '0.6s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-0 px-4 d-flex justify-content-between align-items-center">
                <h6 className="fw-bold text-dark mb-0">My Supervised Projects</h6>
                <a href="#" className="text-decoration-none text-primary fw-semibold" style={{ fontSize: '0.85rem' }}>View All</a>
              </div>
              <div className="card-body p-4 pt-3">
                <div className="table-responsive">
                  <table className="table table-hover align-middle spms-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '35%' }}>Project Name</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '25%' }}>Students</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '25%' }}>Progress</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3 text-end" style={{ width: '15%' }}>Deadline</th>
                      </tr>
                    </thead>
                    <tbody>
                      {myProjects.map((project) => (
                        <tr key={project.id}>
                          <td>
                            <span className="fw-semibold text-dark">{project.title}</span>
                          </td>
                          <td>
                            <span className="text-secondary small fw-medium">{project.students}</span>
                          </td>
                          <td>
                            <div className="d-flex align-items-center">
                              <div className="progress w-100 me-2" style={{ height: '6px', borderRadius: '4px' }}>
                                <div 
                                  className="progress-bar" 
                                  role="progressbar" 
                                  style={{ width: `${project.progress}%`, backgroundColor: getProgressColor(project.progress) }} 
                                  aria-valuenow={project.progress} 
                                  aria-valuemin="0" 
                                  aria-valuemax="100"
                                ></div>
                              </div>
                              <span className="fw-bold text-dark" style={{ fontSize: '0.8rem', minWidth: '35px' }}>{project.progress}%</span>
                            </div>
                          </td>
                          <td className="text-secondary text-end small fw-medium">{project.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Task Status Distribution (Faculty Specific) */}
          <div className="col-12 col-xl-4 spms-animate-up" style={{ animationDelay: '0.7s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-0 px-4">
                <h6 className="fw-bold text-dark mb-0">Student Task Status</h6>
              </div>
              <div className="card-body p-4 d-flex flex-column justify-content-center">
                
                <div className="mb-4">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>Completed by Students</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>60%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '60%', backgroundColor: '#20C997' }} aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>In Progress</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>30%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '30%', backgroundColor: '#6B5CA5' }} aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

                <div className="mb-2">
                  <div className="d-flex justify-content-between mb-1">
                    <span className="fw-semibold text-secondary" style={{ fontSize: '0.9rem' }}>Overdue / At Risk</span>
                    <span className="fw-bold text-dark" style={{ fontSize: '0.9rem' }}>10%</span>
                  </div>
                  <div className="progress" style={{ height: '8px', borderRadius: '10px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: '10%', backgroundColor: '#EF4444' }} aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>

        {/* Row 3: Actionable Area (Tasks Requiring Evaluation) */}
        <div className="row g-4">
            <div className="col-12 spms-animate-up" style={{ animationDelay: '0.9s' }}>
            <div className="card spms-premium-card border-0 h-100">
              <div className="card-header bg-white border-bottom-0 pt-4 pb-0 px-4 d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="fw-bold text-dark mb-1">Tasks Requiring Evaluation</h6>
                  <p className="text-muted small mb-0">These tasks have been completed by students and need your final score.</p>
                </div>
                <a href="#" className="btn btn-sm spms-btn-primary shadow-sm px-3">Go to Scores & Remarks</a>
              </div>
              <div className="card-body p-4 pt-3">
                <div className="table-responsive">
                  <table className="table table-hover align-middle spms-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '30%' }}>Task Title</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '25%' }}>Project</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '20%' }}>Student</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3" style={{ width: '15%' }}>Submitted On</th>
                        <th scope="col" className="text-muted fw-bold text-uppercase pb-3 text-center" style={{ width: '10%' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasksToEvaluate.map((task) => (
                        <tr key={task.id}>
                          <td>
                            <span className="fw-semibold text-dark">{task.title}</span>
                          </td>
                          <td>
                            <span className="text-secondary small fw-medium">{task.project}</span>
                          </td>
                          <td className="text-secondary fw-medium">
                            <div className="d-flex align-items-center">
                              <div className="avatar-circle me-2 bg-light text-primary fw-bold" style={{ width: '24px', height: '24px', fontSize: '0.7rem' }}>
                                {task.student.charAt(0)}
                              </div>
                              <span style={{ fontSize: '0.9rem' }}>{task.student}</span>
                            </div>
                          </td>
                          <td className="text-secondary small fw-medium">{task.submittedDate}</td>
                          <td className="text-center">
                            <button className="btn btn-sm spms-btn-outline-primary d-flex align-items-center justify-content-center gap-2 mx-auto">
                              Evaluate
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* =========================================
          2. STYLE TAG (Placed after UI code)
          ========================================= */}
      <style>
        {`
          /* Professional Keyframe Animations */
          @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
          }

          .spms-animate-up {
            opacity: 0; 
            animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          }

          /* Premium Card Styling */
          .spms-premium-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            border-top: 4px solid #6B5CA5 !important; 
          }

          /* KPI Card Styling */
          .spms-kpi-card {
            border-radius: 12px;
            background-color: #FFFFFF;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
          }
          .spms-kpi-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08) !important;
          }
          .kpi-icon-box {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
          }

          /* Primary Button */
          .spms-btn-primary {
            background-color: #6B5CA5;
            color: #FFFFFF;
            font-weight: 600;
            padding: 8px 18px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s ease;
            font-size: 0.85rem;
          }
          .spms-btn-primary:hover {
            background-color: #55488c;
            color: #FFFFFF;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(107, 92, 165, 0.2);
          }

          /* Outline Button */
          .spms-btn-outline {
            color: #6B5CA5;
            border: 1px solid rgba(107, 92, 165, 0.3);
            font-weight: 600;
            padding: 8px 18px;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 0.85rem;
          }
          .spms-btn-outline:hover {
            background-color: #F8FAFC;
            border-color: #6B5CA5;
          }

          /* Action Buttons inside Table */
          .spms-btn-outline-primary {
            color: #6B5CA5;
            background-color: transparent;
            border: 1px solid rgba(107, 92, 165, 0.3);
            font-weight: 600;
            border-radius: 6px;
            padding: 4px 12px;
            font-size: 0.75rem;
            transition: all 0.2s;
          }
          .spms-btn-outline-primary:hover {
            background-color: #6B5CA5;
            color: #FFFFFF;
            border-color: #6B5CA5;
          }

          /* Table Styling */
          .spms-table th {
            font-size: 0.70rem;
            letter-spacing: 0.8px;
            border-bottom: 2px solid #F1F5F9;
            color: #64748B !important;
          }
          .spms-table td {
            font-size: 0.95rem;
            padding: 16px 10px;
            border-bottom: 1px solid #F1F5F9;
            vertical-align: middle;
          }
          .spms-table tbody tr:last-child td {
            border-bottom: none;
          }

          /* Avatar Circle */
          .avatar-circle {
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(107, 92, 165, 0.2);
          }
        `}
      </style>
    </>
  );
};

export default FacultyDashboard;