import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import './App.css';
import Layout from './component/layout';
import Dashboard from './page/admin/dashboard';
import ManageRoles from './page/admin/manageRole';
import AddRole from './page/admin/addRole';
import ManageUsers from './page/admin/manageUser';
import AddUser from './page/admin/addUser';
import ManageProject from './page/admin/manageProject';
import AddProject from './page/admin/addProject';
import ManageTask from './page/admin/manageTask';
import AddTask from './page/admin/addTask';
import Login from './page/login';
import Profile from './page/profilePgae';
import Reports from './page/admin/reportPage';
import ManageUserRole from './page/admin/manageUserRole';
import ScoresAndRemarks from './page/admin/scoreAndRemarkPage';
import ProjectDetails from './page/admin/projectDetailPgae';
import ManagePriority from './page/admin/managePriority';
import AddPriority from './page/admin/addPriority';
import FacultyDashboard from './page/faculty/dashboard';
import AssignRole from './page/admin/assingRole';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path='/faculty' element={<Layout/>}>
          <Route path='/faculty' element={<FacultyDashboard/>}/>
        </Route>
        <Route path='/' element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/manage-role" element={<ManageRoles />} />
          <Route path="/add-role" element={<AddRole />} />
          <Route path="/manage-user" element={<ManageUsers />} />
          <Route path="/add-user" element={<AddUser />} />
          <Route path="/manage-project" element={<ManageProject />} />
          <Route path="/add-project" element={<AddProject />} />
          <Route path="/manage-task" element={<ManageTask />} />
          <Route path="/add-task" element={<AddTask />} />
          <Route path="/profile-page" element={<Profile />} />
          <Route path='/report' element={<Reports/>}/>
          <Route path='/manage-user-role' element={<ManageUserRole/>}/>
          <Route path='/score-remark' element={<ScoresAndRemarks/>}/>
          <Route path='/project-detail' element={<ProjectDetails/>}/>
          <Route path='/manage-priority' element={<ManagePriority/>}/>
          <Route path='/add-priority' element={<AddPriority/>}/>
          <Route path='/assign_role' element={<AssignRole/>}/>
        </Route>
      
      </Routes>
    </BrowserRouter>
  );
}

export default App;
